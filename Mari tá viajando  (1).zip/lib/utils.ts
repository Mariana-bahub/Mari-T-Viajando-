export function cn(
  ...classes: (string | undefined | false)[]
) {
  return classes
    .filter(Boolean)
    .join(" ");
}


export function formatPrice(
  price: number
) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(price);
}


export function createSlug(
  text: string
) {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-");
}