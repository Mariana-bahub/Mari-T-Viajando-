import Link from "next/link";

export default function Hero() {
  return (
    <section
      className="relative bg-blue-600 text-white py-24 px-8"
    >

      <div className="max-w-7xl mx-auto text-center">


        <h1 className="text-5xl font-bold mb-6">
          Descubra lugares incríveis
        </h1>


        <p className="text-xl max-w-2xl mx-auto mb-8">
          Encontre destinos, hotéis, passagens e dicas
          para transformar sua próxima viagem em uma experiência inesquecível.
        </p>


        <div className="flex justify-center gap-4">


          <Link
            href="/destinos"
            className="bg-white text-blue-600 px-8 py-3 rounded-full font-bold"
          >
            Explorar destinos
          </Link>


          <Link
            href="/passagens"
            className="border border-white px-8 py-3 rounded-full font-bold"
          >
            Ver passagens
          </Link>


        </div>


      </div>


    </section>
  );
}