export default function SearchBar() {
  return (
    <div className="max-w-5xl mx-auto bg-white shadow-lg rounded-xl p-6">

      <div className="grid md:grid-cols-4 gap-4">


        <div>
          <label className="block text-sm font-semibold mb-2">
            Origem
          </label>

          <input
            type="text"
            placeholder="De onde você sai?"
            className="w-full border rounded-lg p-3"
          />
        </div>


        <div>
          <label className="block text-sm font-semibold mb-2">
            Destino
          </label>

          <input
            type="text"
            placeholder="Para onde vai?"
            className="w-full border rounded-lg p-3"
          />
        </div>


        <div>
          <label className="block text-sm font-semibold mb-2">
            Data
          </label>

          <input
            type="date"
            className="w-full border rounded-lg p-3"
          />
        </div>


        <div className="flex items-end">

          <button
            className="w-full bg-blue-600 text-white p-3 rounded-lg font-bold"
          >
            Pesquisar
          </button>

        </div>


      </div>


    </div>
  );
}