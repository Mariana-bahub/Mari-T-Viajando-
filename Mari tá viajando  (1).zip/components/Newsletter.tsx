export default function Newsletter() {
  return (
    <section className="bg-blue-600 text-white py-12 px-8">

      <div className="max-w-4xl mx-auto text-center">


        <h2 className="text-3xl font-bold mb-4">
          Receba dicas de viagem
        </h2>


        <p className="mb-8 text-lg">
          Cadastre seu e-mail e receba novidades,
          promoções e inspirações para viajar.
        </p>


        <form className="flex flex-col md:flex-row gap-4 justify-center">


          <input
            type="email"
            placeholder="Digite seu melhor e-mail"
            className="px-5 py-3 rounded-lg text-gray-800 w-full md:w-96"
          />


          <button
            type="submit"
            className="bg-white text-blue-600 font-bold px-8 py-3 rounded-lg"
          >
            Quero receber
          </button>


        </form>


      </div>


    </section>
  );
}