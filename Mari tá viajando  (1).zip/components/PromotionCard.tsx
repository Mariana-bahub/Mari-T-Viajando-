type PromotionCardProps = {
  title: string;
  description: string;
  price?: string;
};


export default function PromotionCard({
  title,
  description,
  price,
}: PromotionCardProps) {

  return (
    <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-xl transition">


      <div className="mb-4">

        <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-semibold">
          Promoção
        </span>

      </div>


      <h3 className="text-2xl font-bold mb-3">
        {title}
      </h3>


      <p className="text-gray-600 mb-4">
        {description}
      </p>


      {price && (
        <p className="text-xl font-bold text-blue-600 mb-4">
          {price}
        </p>
      )}


      <button
        className="bg-blue-600 text-white px-6 py-2 rounded-lg"
      >
        Aproveitar oferta
      </button>


    </div>
  );
}