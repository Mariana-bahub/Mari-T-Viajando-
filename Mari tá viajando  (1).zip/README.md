# Mari Tá Viajando ✈️🌎

Projeto de um site de viagens criado com Next.js, React e Tailwind CSS.

## Sobre o projeto

O Mari Tá Viajando é uma plataforma de conteúdo sobre viagens,
com destinos, passagens, hotéis, dicas e artigos para ajudar
pessoas a planejarem suas próximas aventuras.

## Tecnologias usadas

- Next.js
- React
- TypeScript
- Tailwind CSS
- CSS

## Estrutura do projeto