export const artigos = [
  {
    id: 1,
    title: "10 destinos incríveis para conhecer no Brasil",
    slug: "destinos-incriveis-brasil",
    image: "/images/blog/brasil.jpg",
    description:
      "Veja lugares incríveis para colocar na sua lista de viagens."
  },

  {
    id: 2,
    title: "Como viajar gastando pouco",
    slug: "viajar-gastando-pouco",
    image: "/images/blog/economia.jpg",
    description:
      "Dicas para economizar e aproveitar mais sua viagem."
  },

  {
    id: 3,
    title: "Como organizar a mala perfeita",
    slug: "organizar-mala",
    image: "/images/blog/mala.jpg",
    description:
      "Aprenda a preparar sua bagagem sem esquecer nada."
  }
];