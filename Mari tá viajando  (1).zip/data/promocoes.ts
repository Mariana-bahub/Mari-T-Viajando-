export const promocoes = [
  {
    id: 1,
    title: "Passagens para Salvador",
    description:
      "Aproveite preços especiais para conhecer a Bahia.",
    price:
      "A partir de R$ 299"
  },

  {
    id: 2,
    title: "Pacote Gramado",
    description:
      "Hospedagem e experiências em um dos destinos mais românticos.",
    price:
      "A partir de R$ 899"
  },

  {
    id: 3,
    title: "Viagem para Rio de Janeiro",
    description:
      "Confira ofertas para curtir as praias cariocas.",
    price:
      "A partir de R$ 399"
  }
];