export const destinos = [
  {
    id: 1,
    title: "Fernando de Noronha",
    image: "/images/destinos/noronha.jpg",
    description:
      "Praias paradisíacas e águas cristalinas em um dos lugares mais incríveis do Brasil."
  },

  {
    id: 2,
    title: "Rio de Janeiro",
    image: "/images/destinos/rio.jpg",
    description:
      "Conheça praias famosas, o Cristo Redentor e paisagens inesquecíveis."
  },

  {
    id: 3,
    title: "Gramado",
    image: "/images/destinos/gramado.jpg",
    description:
      "Um destino com charme europeu, gastronomia e atrações para toda família."
  },

  {
    id: 4,
    title: "Salvador",
    image: "/images/destinos/salvador.jpg",
    description:
      "Cultura, história, música e belas praias na capital baiana."
  }
];